def handler(event,context):
    print("Wow that worked")